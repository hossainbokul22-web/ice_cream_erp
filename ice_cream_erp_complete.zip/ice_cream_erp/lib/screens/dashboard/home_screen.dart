import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../inventory/receive_stock_screen.dart';
import '../reports/daily_production_report.dart';
import '../reports/material_consumption_report.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ice Cream ERP')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _quickBtn(context, 'Opening Balance', Icons.account_balance_wallet, Colors.deepOrange, () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: true)));
                }),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _quickBtn(context, 'Purchase Receive', Icons.add_shopping_cart, Colors.teal, () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: false)));
                }),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Main Modules', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _moduleTile(context, Icons.precision_manufacturing, 'Production', 'Batch Issue, Tank, Overrun, Cost/L', '/production', Colors.deepPurple),
          _moduleTile(context, Icons.inventory_2, 'Stock Summary', 'Closing Balance + Batches', '/stock', Colors.teal),
          _moduleTile(context, Icons.science, 'Recipes / BOM', 'Auto Material Calculation', '/recipes', Colors.indigo),
          _moduleTile(context, Icons.water_drop, 'Tanks', 'Mixing & Aging status', '/tanks', Colors.cyan),
          _moduleTile(context, Icons.category, 'Item Master', 'Raw, Packaging, Finished', '/items', Colors.brown),
          _moduleTile(context, Icons.receipt_long, 'Vouchers', 'Purchase, Sales, Payment', '/vouchers', Colors.blueGrey),
          const SizedBox(height: 12),
          const Text('Reports', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _moduleTile(context, Icons.assessment, 'Daily Production Report', 'Mix, Finished, Overrun, Cost', null, Colors.green, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyProductionReportScreen()));
          }),
          _moduleTile(context, Icons.list_alt, 'Material Consumption', 'কোন কাঁচামাল কত খরচ হয়েছে', null, Colors.orange, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MaterialConsumptionReportScreen()));
          }),
          _moduleTile(context, Icons.account_balance, 'Profit & Loss', 'P&L Statement', '/profit-loss', Colors.green.shade800),
        ],
      ),
    );
  }

  Widget _quickBtn(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      color: color.withOpacity(0.1),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Icon(icon, color: color, size: 28),
              const SizedBox(height: 6),
              Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _moduleTile(BuildContext context, IconData icon, String title, String subtitle, String? route, Color color, {VoidCallback? onTap}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap ?? (route != null ? () => context.push(route) : null),
      ),
    );
  }
}
