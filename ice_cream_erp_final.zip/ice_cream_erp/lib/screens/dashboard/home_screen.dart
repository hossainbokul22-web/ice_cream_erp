import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../inventory/receive_stock_screen.dart';
import '../inventory/stock_adjustment_screen.dart';
import '../accounts/sales_screen.dart';
import '../reports/daily_production_report.dart';
import '../reports/material_consumption_report.dart';
import '../reports/expiry_alert_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ice Cream ERP')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _quickBtn(context, 'Opening\nBalance', Icons.account_balance_wallet, Colors.deepOrange, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: true)));
              })),
              const SizedBox(width: 8),
              Expanded(child: _quickBtn(context, 'Purchase\nReceive', Icons.add_shopping_cart, Colors.teal, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: false)));
              })),
              const SizedBox(width: 8),
              Expanded(child: _quickBtn(context, 'Sales', Icons.point_of_sale, Colors.green, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const SalesScreen()));
              })),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Inventory & Production', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.precision_manufacturing, 'Production', 'Batch Issue, Overrun, Cost/L', '/production', Colors.deepPurple),
          _tile(context, Icons.inventory_2, 'Stock Summary', 'Closing Balance + Batches', '/stock', Colors.teal),
          _tile(context, Icons.tune, 'Stock Adjustment / Wastage', 'নষ্ট বা Adjustment', null, Colors.red, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const StockAdjustmentScreen()));
          }),
          _tile(context, Icons.science, 'Recipes / BOM', 'Auto Material Calculation', '/recipes', Colors.indigo),
          _tile(context, Icons.water_drop, 'Tanks', 'Mixing & Aging', '/tanks', Colors.cyan),
          _tile(context, Icons.category, 'Item Master', 'Raw, Packaging, Finished', '/items', Colors.brown),
          const SizedBox(height: 12),
          const Text('Reports', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.assessment, 'Daily Production Report', 'Mix, Finished, Overrun', null, Colors.green, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyProductionReportScreen()));
          }),
          _tile(context, Icons.list_alt, 'Material Consumption', 'কাঁচামাল খরচ', null, Colors.orange, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MaterialConsumptionReportScreen()));
          }),
          _tile(context, Icons.warning_amber, 'Expiry Alert', '৩০ দিনের মধ্যে Expiry', null, Colors.deepOrange, onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpiryAlertScreen()));
          }),
          _tile(context, Icons.account_balance, 'Profit & Loss', 'Sales vs Production Cost', '/profit-loss', Colors.green.shade800),
          _tile(context, Icons.receipt_long, 'Vouchers', 'All vouchers', '/vouchers', Colors.blueGrey),
        ],
      ),
    );
  }

  Widget _quickBtn(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      color: color.withOpacity(0.1),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
          child: Column(
            children: [
              Icon(icon, color: color, size: 26),
              const SizedBox(height: 6),
              Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String subtitle, String? route, Color color, {VoidCallback? onTap}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color, size: 22)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: const Icon(Icons.chevron_right, size: 20),
        onTap: onTap ?? (route != null ? () => context.push(route) : null),
      ),
    );
  }
}
