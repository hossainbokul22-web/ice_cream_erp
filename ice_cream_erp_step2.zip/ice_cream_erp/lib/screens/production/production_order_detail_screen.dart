import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../services/production_service.dart';
import '../../services/stock_service.dart';
import '../../database/app_database.dart';

class ProductionOrderDetailScreen extends ConsumerStatefulWidget {
  final int orderId;
  const ProductionOrderDetailScreen({super.key, required this.orderId});

  @override
  ConsumerState<ProductionOrderDetailScreen> createState() => _ProductionOrderDetailScreenState();
}

class _ProductionOrderDetailScreenState extends ConsumerState<ProductionOrderDetailScreen> {
  Map<String, dynamic>? details;
  List<Map<String, dynamic>>? requiredMaterials;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final service = ref.read(productionServiceProvider);
    final data = await service.getOrderDetails(widget.orderId);
    List<Map<String, dynamic>>? materials;
    if (data['order'].status == 'Planned' || data['order'].status == 'Mixing') {
      materials = await service.getRequiredMaterials(widget.orderId);
    }
    setState(() {
      details = data;
      requiredMaterials = materials;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (details == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final order = details!['order'];
    final recipe = details!['recipe'];

    return Scaffold(
      appBar: AppBar(title: Text(order.orderNo)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _infoCard('Status', order.status),
          _infoCard('Recipe', recipe.recipeName),
          _infoCard('Target Mix', '${order.targetQty} L'),
          if (order.actualMixQty != null) _infoCard('Actual Mix', '${order.actualMixQty} L'),
          if (order.actualFinishedQty != null) _infoCard('Finished Qty', '${order.actualFinishedQty} L'),
          if (order.actualOverrun != null) _infoCard('Actual Overrun', '${order.actualOverrun.toStringAsFixed(1)} %'),
          if (order.actualYield != null) _infoCard('Yield', '${order.actualYield.toStringAsFixed(1)} %'),
          if (details!['costPerLiterFinished'] != null)
            _infoCard('Cost per Liter', '${(details!['costPerLiterFinished'] as double).toStringAsFixed(2)} Tk'),

          // ===== Required Materials from Recipe (Auto) =====
          if (requiredMaterials != null && requiredMaterials!.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('Recipe থেকে Required Materials (Auto)', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            ...requiredMaterials!.map((m) {
              return Card(
                child: ListTile(
                  dense: true,
                  title: Text('${m['itemCode']} - ${m['itemName']}'),
                  subtitle: Text('Required: ${(m['requiredQty'] as double).toStringAsFixed(2)} ${m['unit']}  (Wastage ${m['wastagePercent']}%)'),
                ),
              );
            }),
          ],

          const SizedBox(height: 20),
          const Text('Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),

          if (order.status == 'Planned') ...[
            FilledButton.icon(
              onPressed: () => _showBatchIssueDialog(),
              icon: const Icon(Icons.output),
              label: const Text('1. Material Issue (Batch সিলেক্ট করে)'),
            ),
          ],
          if (order.status == 'Mixing') ...[
            FilledButton.icon(
              onPressed: () => _completeMixing(),
              icon: const Icon(Icons.check),
              label: const Text('2. Mixing সম্পন্ন + Actual Mix Qty'),
            ),
          ],
          if (order.status == 'Aging') ...[
            FilledButton.icon(
              onPressed: () => _completeProduction(),
              icon: const Icon(Icons.done_all),
              label: const Text('3. Freezing সম্পন্ন + Finished Qty'),
            ),
          ],
          if (order.status == 'Completed')
            const Card(
              color: Colors.green,
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text('প্রোডাকশন সম্পন্ন হয়েছে', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _infoCard(String label, String value) {
    return Card(
      child: ListTile(
        dense: true,
        title: Text(label, style: const TextStyle(fontSize: 13, color: Colors.grey)),
        trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
      ),
    );
  }

  /// Batch সিলেক্ট করে Material Issue
  Future<void> _showBatchIssueDialog() async {
    if (requiredMaterials == null || requiredMaterials!.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Required materials পাওয়া যায়নি')));
      return;
    }

    final stockService = ref.read(stockServiceProvider);
    final productionService = ref.read(productionServiceProvider);

    // প্রতিটি material এর জন্য available batches নিয়ে আসি
    Map<int, List<Batch>> itemBatches = {};
    Map<int, Batch?> selectedBatches = {};
    Map<int, TextEditingController> qtyControllers = {};

    for (final m in requiredMaterials!) {
      final itemId = m['itemId'] as int;
      final batches = await stockService.getAvailableBatches(itemId);
      itemBatches[itemId] = batches;
      selectedBatches[itemId] = batches.isNotEmpty ? batches.first : null;
      qtyControllers[itemId] = TextEditingController(text: (m['requiredQty'] as double).toStringAsFixed(2));
    }

    if (!mounted) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text('Material Issue - Batch সিলেক্ট করুন', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    ...requiredMaterials!.map((m) {
                      final itemId = m['itemId'] as int;
                      final batches = itemBatches[itemId] ?? [];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${m['itemCode']} - ${m['itemName']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                              Text('Required: ${(m['requiredQty'] as double).toStringAsFixed(2)} ${m['unit']}'),
                              const SizedBox(height: 6),
                              if (batches.isEmpty)
                                const Text('স্টক নেই / Batch নেই', style: TextStyle(color: Colors.red))
                              else ...[
                                DropdownButtonFormField<Batch>(
                                  value: selectedBatches[itemId],
                                  decoration: const InputDecoration(labelText: 'Batch সিলেক্ট', isDense: true, border: OutlineInputBorder()),
                                  items: batches.map((b) {
                                    return DropdownMenuItem(
                                      value: b,
                                      child: Text('${b.batchNo} (Qty: ${b.currentQty.toStringAsFixed(1)}, Exp: ${b.expiryDate != null ? b.expiryDate.toString().substring(0,10) : "N/A"})'),
                                    );
                                  }).toList(),
                                  onChanged: (v) => setModalState(() => selectedBatches[itemId] = v),
                                ),
                                const SizedBox(height: 6),
                                TextField(
                                  controller: qtyControllers[itemId],
                                  keyboardType: TextInputType.number,
                                  decoration: const InputDecoration(labelText: 'Issue Qty', isDense: true, border: OutlineInputBorder()),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    }),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: () async {
                        List<Map<String, dynamic>> issues = [];
                        for (final m in requiredMaterials!) {
                          final itemId = m['itemId'] as int;
                          final batch = selectedBatches[itemId];
                          final qty = double.tryParse(qtyControllers[itemId]?.text ?? '0') ?? 0;
                          if (batch == null || qty <= 0) continue;
                          issues.add({
                            'itemId': itemId,
                            'batchId': batch.id,
                            'qty': qty,
                            'unitCost': batch.unitCost,
                          });
                        }
                        if (issues.isEmpty) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('কোনো material issue করা হয়নি')));
                          return;
                        }
                        await productionService.issueMaterials(productionOrderId: widget.orderId, issues: issues);
                        if (ctx.mounted) Navigator.pop(ctx);
                        _load();
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Material Issued (Batch সহ)')));
                        }
                      },
                      child: const Text('Confirm Issue'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _completeMixing() {
    final qtyCtrl = TextEditingController(text: details!['order'].targetQty.toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Actual Mix Quantity'),
        content: TextField(controller: qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Actual Mix Qty (L)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final service = ref.read(productionServiceProvider);
              final order = details!['order'];
              await service.completeMixing(
                productionOrderId: widget.orderId,
                actualMixQty: double.tryParse(qtyCtrl.text) ?? order.targetQty,
                mixingTankId: order.mixingTankId ?? 1,
              );
              if (order.agingTankId != null) {
                await service.moveToAging(productionOrderId: widget.orderId, agingTankId: order.agingTankId);
              }
              Navigator.pop(ctx);
              _load();
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _completeProduction() {
    final finishedCtrl = TextEditingController();
    final batchCtrl = TextEditingController(text: 'FG-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Finished Goods Receipt'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: finishedCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Actual Finished Qty (Liter)')),
            const SizedBox(height: 8),
            TextField(controller: batchCtrl, decoration: const InputDecoration(labelText: 'Finished Batch No')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () async {
              final service = ref.read(productionServiceProvider);
              final order = details!['order'];
              final recipe = details!['recipe'];
              await service.completeProduction(
                productionOrderId: widget.orderId,
                actualFinishedQty: double.tryParse(finishedCtrl.text) ?? 0,
                finishedBatchNo: batchCtrl.text.trim(),
                finishedItemId: recipe.finishedItemId,
                warehouseId: 1,
              );
              Navigator.pop(ctx);
              _load();
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Production Completed + Cost Calculated')));
            },
            child: const Text('Complete'),
          ),
        ],
      ),
    );
  }
}
