import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';
import '../../services/stock_service.dart';

class StockAdjustmentScreen extends ConsumerStatefulWidget {
  const StockAdjustmentScreen({super.key});

  @override
  ConsumerState<StockAdjustmentScreen> createState() => _StockAdjustmentScreenState();
}

class _StockAdjustmentScreenState extends ConsumerState<StockAdjustmentScreen> {
  int? selectedItemId;
  Batch? selectedBatch;
  List<Batch> batches = [];
  final qtyCtrl = TextEditingController();
  final reasonCtrl = TextEditingController();
  String adjType = 'Wastage'; // Wastage, Adjustment+, Adjustment-

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Stock Adjustment / Wastage')),
      body: FutureBuilder(
        future: (db.select(db.items)..where((i) => i.isActive.equals(true))).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final items = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              DropdownButtonFormField<String>(
                value: adjType,
                decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'Wastage', child: Text('Wastage / নষ্ট')),
                  DropdownMenuItem(value: 'Adjustment-', child: Text('Stock কমানো (Adjustment)')),
                  DropdownMenuItem(value: 'Adjustment+', child: Text('Stock বাড়ানো (Adjustment)')),
                ],
                onChanged: (v) => setState(() => adjType = v!),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: selectedItemId,
                decoration: const InputDecoration(labelText: 'Item', border: OutlineInputBorder()),
                items: items.map((i) => DropdownMenuItem(value: i.id, child: Text('${i.itemCode} - ${i.itemName}'))).toList(),
                onChanged: (v) async {
                  setState(() {
                    selectedItemId = v;
                    selectedBatch = null;
                    batches = [];
                  });
                  if (v != null) {
                    final b = await ref.read(stockServiceProvider).getAvailableBatches(v);
                    setState(() => batches = b);
                  }
                },
              ),
              const SizedBox(height: 12),
              if (batches.isNotEmpty)
                DropdownButtonFormField<Batch>(
                  value: selectedBatch,
                  decoration: const InputDecoration(labelText: 'Batch', border: OutlineInputBorder()),
                  items: batches.map((b) => DropdownMenuItem(
                    value: b,
                    child: Text('${b.batchNo} (Qty: ${b.currentQty.toStringAsFixed(1)})'),
                  )).toList(),
                  onChanged: (v) => setState(() => selectedBatch = v),
                ),
              const SizedBox(height: 12),
              TextField(controller: qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: reasonCtrl, decoration: const InputDecoration(labelText: 'Reason / Narration', border: OutlineInputBorder())),
              const SizedBox(height: 24),
              FilledButton(onPressed: _save, child: const Text('সেভ করুন')),
            ],
          );
        },
      ),
    );
  }

  Future<void> _save() async {
    if (selectedItemId == null || selectedBatch == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Item ও Batch সিলেক্ট করুন')));
      return;
    }
    final qty = double.tryParse(qtyCtrl.text) ?? 0;
    if (qty <= 0) return;

    final db = ref.read(databaseProvider);
    final isIncrease = adjType == 'Adjustment+';

    await db.transaction(() async {
      await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
        voucherType: adjType,
        itemId: selectedItemId!,
        batchId: Value(selectedBatch!.id),
        qtyIn: Value(isIncrease ? qty : 0),
        qtyOut: Value(isIncrease ? 0 : qty),
        unitCost: Value(selectedBatch!.unitCost),
        transactionDate: DateTime.now(),
        narration: Value(reasonCtrl.text.trim().isEmpty ? adjType : reasonCtrl.text.trim()),
      ));

      final newQty = isIncrease
          ? selectedBatch!.currentQty + qty
          : selectedBatch!.currentQty - qty;

      await (db.update(db.batches)..where((b) => b.id.equals(selectedBatch!.id)))
          .write(BatchesCompanion(currentQty: Value(newQty < 0 ? 0 : newQty)));
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Adjustment সেভ হয়েছে')));
      Navigator.pop(context);
    }
  }
}
