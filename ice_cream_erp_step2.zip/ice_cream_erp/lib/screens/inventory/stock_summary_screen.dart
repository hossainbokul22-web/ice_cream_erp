import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/database_provider.dart';
import '../../services/stock_service.dart';
import 'receive_stock_screen.dart';

class StockSummaryScreen extends ConsumerWidget {
  const StockSummaryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stockService = ref.watch(stockServiceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Stock Summary (Closing)'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            tooltip: 'Receive Stock',
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: false)));
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: stockService.getStockSummary(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final summary = snapshot.data!;
          if (summary.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('স্টক নেই'),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: true)));
                    },
                    child: const Text('Opening Balance দিন'),
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(10),
            itemCount: summary.length,
            itemBuilder: (context, index) {
              final row = summary[index];
              final item = row['item'];
              final stock = row['currentStock'] as double;
              final value = row['stockValue'] as double;
              final isLow = row['isLowStock'] as bool;
              final batches = row['batches'] as List;

              return Card(
                color: isLow ? Colors.red.shade50 : null,
                child: ExpansionTile(
                  title: Text('${item.itemCode} - ${item.itemName}', style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('Closing: ${stock.toStringAsFixed(2)} ${item.baseUnit}  |  Value: ${value.toStringAsFixed(0)} Tk'),
                  trailing: isLow ? const Icon(Icons.warning, color: Colors.red) : null,
                  children: [
                    if (batches.isEmpty)
                      const ListTile(title: Text('কোনো ব্যাচ নেই'))
                    else
                      ...batches.map((b) {
                        return ListTile(
                          dense: true,
                          title: Text('Batch: ${b.batchNo}'),
                          subtitle: Text('Qty: ${b.currentQty.toStringAsFixed(2)}  |  Cost: ${b.unitCost.toStringAsFixed(2)}  |  Exp: ${b.expiryDate != null ? b.expiryDate.toString().substring(0,10) : "N/A"}'),
                        );
                      }),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
