import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';
import '../../services/stock_service.dart';

class ReceiveStockScreen extends ConsumerStatefulWidget {
  final bool isOpening;
  const ReceiveStockScreen({super.key, this.isOpening = false});

  @override
  ConsumerState<ReceiveStockScreen> createState() => _ReceiveStockScreenState();
}

class _ReceiveStockScreenState extends ConsumerState<ReceiveStockScreen> {
  int? selectedItemId;
  final qtyCtrl = TextEditingController();
  final costCtrl = TextEditingController();
  final batchCtrl = TextEditingController();
  final narrationCtrl = TextEditingController();
  DateTime? expiryDate;

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isOpening ? 'Opening Balance' : 'Purchase / Receive Stock'),
      ),
      body: FutureBuilder(
        future: (db.select(db.items)..where((i) => i.isActive.equals(true))).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final items = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              DropdownButtonFormField<int>(
                value: selectedItemId,
                decoration: const InputDecoration(labelText: 'Raw Material / Item সিলেক্ট করুন', border: OutlineInputBorder()),
                items: items.map((item) {
                  return DropdownMenuItem(
                    value: item.id,
                    child: Text('${item.itemCode} - ${item.itemName} (${item.baseUnit})'),
                  );
                }).toList(),
                onChanged: (v) => setState(() => selectedItemId = v),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: qtyCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Quantity', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: costCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Unit Cost (Tk)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: batchCtrl,
                decoration: const InputDecoration(labelText: 'Batch No', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(expiryDate == null ? 'Expiry Date সিলেক্ট করুন' : 'Expiry: ${expiryDate!.toString().substring(0, 10)}'),
                trailing: const Icon(Icons.calendar_today),
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now().add(const Duration(days: 30)),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
                  );
                  if (picked != null) setState(() => expiryDate = picked);
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: narrationCtrl,
                decoration: const InputDecoration(labelText: 'Narration (optional)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: selectedItemId == null ? null : _save,
                child: Text(widget.isOpening ? 'Opening Balance সেভ করুন' : 'Stock Receive করুন'),
              ),
            ],
          );
        },
      ),
    );
  }

  Future<void> _save() async {
    final qty = double.tryParse(qtyCtrl.text) ?? 0;
    final cost = double.tryParse(costCtrl.text) ?? 0;
    if (qty <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Quantity দিন')));
      return;
    }
    if (batchCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Batch No দিন')));
      return;
    }

    final service = ref.read(stockServiceProvider);
    await service.receiveStock(
      itemId: selectedItemId!,
      qty: qty,
      unitCost: cost,
      batchNo: batchCtrl.text.trim(),
      expiryDate: expiryDate,
      voucherType: widget.isOpening ? 'Opening' : 'Purchase',
      narration: narrationCtrl.text.trim().isEmpty ? null : narrationCtrl.text.trim(),
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(widget.isOpening ? 'Opening Balance সেভ হয়েছে' : 'Stock Receive হয়েছে')),
      );
      Navigator.pop(context);
    }
  }
}
