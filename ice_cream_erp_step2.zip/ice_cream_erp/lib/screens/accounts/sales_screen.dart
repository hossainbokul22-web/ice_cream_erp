import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';
import '../../services/stock_service.dart';

class SalesScreen extends ConsumerStatefulWidget {
  const SalesScreen({super.key});

  @override
  ConsumerState<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends ConsumerState<SalesScreen> {
  int? selectedItemId;
  Batch? selectedBatch;
  List<Batch> batches = [];
  final qtyCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  final customerCtrl = TextEditingController();
  final narrationCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Sales / Delivery')),
      body: FutureBuilder(
        future: (db.select(db.items)..where((i) => i.itemType.equals('Finished') & i.isActive.equals(true))).get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final items = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(controller: customerCtrl, decoration: const InputDecoration(labelText: 'Customer Name', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                value: selectedItemId,
                decoration: const InputDecoration(labelText: 'Finished Goods', border: OutlineInputBorder()),
                items: items.map((i) => DropdownMenuItem(value: i.id, child: Text('${i.itemCode} - ${i.itemName}'))).toList(),
                onChanged: (v) async {
                  setState(() {
                    selectedItemId = v;
                    selectedBatch = null;
                    batches = [];
                  });
                  if (v != null) {
                    final b = await ref.read(stockServiceProvider).getAvailableBatches(v);
                    setState(() => batches = b);
                    final item = items.firstWhere((e) => e.id == v);
                    priceCtrl.text = item.salesPrice.toString();
                  }
                },
              ),
              const SizedBox(height: 12),
              if (batches.isNotEmpty)
                DropdownButtonFormField<Batch>(
                  value: selectedBatch,
                  decoration: const InputDecoration(labelText: 'Batch', border: OutlineInputBorder()),
                  items: batches.map((b) => DropdownMenuItem(
                    value: b,
                    child: Text('${b.batchNo} (Available: ${b.currentQty.toStringAsFixed(1)})'),
                  )).toList(),
                  onChanged: (v) => setState(() => selectedBatch = v),
                ),
              const SizedBox(height: 12),
              TextField(controller: qtyCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity (Liter / Pcs)', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Sale Price per Unit', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: narrationCtrl, decoration: const InputDecoration(labelText: 'Narration', border: OutlineInputBorder())),
              const SizedBox(height: 24),
              FilledButton(onPressed: _save, child: const Text('Sales সেভ করুন + Stock কমান')),
            ],
          );
        },
      ),
    );
  }

  Future<void> _save() async {
    if (selectedItemId == null || selectedBatch == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Item ও Batch সিলেক্ট করুন')));
      return;
    }
    final qty = double.tryParse(qtyCtrl.text) ?? 0;
    final price = double.tryParse(priceCtrl.text) ?? 0;
    if (qty <= 0) return;
    if (qty > selectedBatch!.currentQty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('স্টকে পর্যাপ্ত Qty নেই')));
      return;
    }

    final db = ref.read(databaseProvider);
    final total = qty * price;

    await db.transaction(() async {
      // Stock Out
      await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
        voucherType: 'Sales',
        itemId: selectedItemId!,
        batchId: Value(selectedBatch!.id),
        qtyOut: Value(qty),
        unitCost: Value(selectedBatch!.unitCost),
        transactionDate: DateTime.now(),
        narration: Value('Sales to ${customerCtrl.text}'),
      ));

      // Batch qty কমাও
      await (db.update(db.batches)..where((b) => b.id.equals(selectedBatch!.id)))
          .write(BatchesCompanion(currentQty: Value(selectedBatch!.currentQty - qty)));

      // Voucher
      final voucherId = await db.into(db.vouchers).insert(VouchersCompanion.insert(
        voucherNo: 'SL-${DateTime.now().millisecondsSinceEpoch}',
        voucherType: 'Sales',
        voucherDate: DateTime.now(),
        totalAmount: total,
        narration: Value('Sales to ${customerCtrl.text.trim()} - ${narrationCtrl.text.trim()}'),
      ));

      await db.into(db.voucherLines).insert(VoucherLinesCompanion.insert(
        voucherId: voucherId, ledgerName: 'Cash/Bank', debit: Value(total)));
      await db.into(db.voucherLines).insert(VoucherLinesCompanion.insert(
        voucherId: voucherId, ledgerName: 'Sales A/c', credit: Value(total)));
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sales সেভ হয়েছে। Total: ${total.toStringAsFixed(0)} Tk')));
      Navigator.pop(context);
    }
  }
}
