import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class ExpiryAlertScreen extends ConsumerWidget {
  const ExpiryAlertScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);
    final now = DateTime.now();
    final soon = now.add(const Duration(days: 30));

    return Scaffold(
      appBar: AppBar(title: const Text('Expiry Alert (৩০ দিনের মধ্যে)')),
      body: FutureBuilder(
        future: (db.select(db.batches)
              ..where((b) => b.currentQty.isBiggerThanValue(0) & b.expiryDate.isNotNull())
              ..orderBy([(b) => OrderingTerm.asc(b.expiryDate)]))
            .get(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data!;
          final alerts = all.where((b) => b.expiryDate != null && b.expiryDate!.isBefore(soon)).toList();

          if (alerts.isEmpty) {
            return const Center(child: Text('৩০ দিনের মধ্যে Expiry হওয়ার মতো Batch নেই'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: alerts.length,
            itemBuilder: (context, index) {
              final b = alerts[index];
              final daysLeft = b.expiryDate!.difference(now).inDays;
              final isExpired = daysLeft < 0;
              final isUrgent = daysLeft <= 7;

              return Card(
                color: isExpired ? Colors.red.shade100 : (isUrgent ? Colors.orange.shade100 : null),
                child: ListTile(
                  title: Text('Batch: ${b.batchNo}'),
                  subtitle: FutureBuilder(
                    future: (db.select(db.items)..where((i) => i.id.equals(b.itemId))).getSingle(),
                    builder: (context, snap) {
                      final name = snap.data?.itemName ?? 'Item ${b.itemId}';
                      return Text('$name\nQty: ${b.currentQty.toStringAsFixed(1)}  |  Exp: ${b.expiryDate.toString().substring(0,10)}');
                    },
                  ),
                  isThreeLine: true,
                  trailing: Text(
                    isExpired ? 'EXPIRED' : '$daysLeft days',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: isExpired || isUrgent ? Colors.red : Colors.orange,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
