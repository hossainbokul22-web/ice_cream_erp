import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/database_provider.dart';

class ProfitLossScreen extends ConsumerWidget {
  const ProfitLossScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Profit & Loss')),
      body: FutureBuilder(
        future: _calculate(db),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final d = snapshot.data!;

          final sales = d['sales'] as double;
          final purchase = d['purchase'] as double;
          final productionCost = d['productionCost'] as double;
          final wastageCost = d['wastageCost'] as double;
          final cogs = purchase + productionCost + wastageCost; // simplified
          final grossProfit = sales - productionCost - wastageCost;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Profit & Loss Statement', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text('All time (from vouchers + production)', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
              const Divider(height: 24),
              _row('Sales', sales, positive: true),
              const SizedBox(height: 8),
              const Text('Less: Cost of Goods', style: TextStyle(fontWeight: FontWeight.w600)),
              _row('  Production Material Cost', productionCost, positive: false),
              _row('  Wastage / Adjustment', wastageCost, positive: false),
              _row('  Purchase (raw reference)', purchase, positive: false),
              const Divider(),
              _row('Gross Profit', grossProfit, positive: grossProfit >= 0, bold: true),
              const SizedBox(height: 20),
              const Text(
                'নোট: এটা উন্নত ভার্সন। Party Ledger ও Overhead যোগ করলে আরও সঠিক P&L হবে।',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _row(String label, double amount, {bool positive = true, bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          Text(
            '${amount.toStringAsFixed(2)} Tk',
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.w600,
              color: positive ? Colors.green.shade700 : Colors.red.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Future<Map<String, double>> _calculate(dynamic db) async {
    final vouchers = await db.select(db.vouchers).get();
    double sales = 0, purchase = 0;
    for (final v in vouchers) {
      if (v.voucherType == 'Sales') sales += v.totalAmount;
      if (v.voucherType == 'Purchase') purchase += v.totalAmount;
    }

    final orders = await db.select(db.productionOrders).get();
    double productionCost = 0;
    for (final o in orders) {
      if (o.status == 'Completed') productionCost += o.totalMaterialCost;
    }

    final ledger = await db.select(db.stockLedger).get();
    double wastageCost = 0;
    for (final l in ledger) {
      if (l.voucherType == 'Wastage' || l.voucherType == 'Adjustment-') {
        wastageCost += (l.qtyOut) * (l.unitCost ?? 0);
      }
    }

    return {
      'sales': sales,
      'purchase': purchase,
      'productionCost': productionCost,
      'wastageCost': wastageCost,
    };
  }
}
