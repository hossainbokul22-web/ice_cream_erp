import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class MaterialConsumptionReportScreen extends ConsumerWidget {
  const MaterialConsumptionReportScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Material Consumption Report')),
      body: FutureBuilder(
        future: _getConsumption(db),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final data = snapshot.data!;
          if (data.isEmpty) {
            return const Center(child: Text('এখনো কোনো Material Issue হয়নি'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: data.length,
            itemBuilder: (context, index) {
              final row = data[index];
              return Card(
                child: ListTile(
                  title: Text(row['itemName']),
                  subtitle: Text('Total Issued: ${row['totalQty'].toStringAsFixed(2)}  |  Total Cost: ${row['totalCost'].toStringAsFixed(0)} Tk'),
                  trailing: Text('${row['issueCount']} times', style: const TextStyle(fontSize: 12)),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _getConsumption(AppDatabase db) async {
    final issues = await db.select(db.productionIssues).get();
    Map<int, Map<String, dynamic>> map = {};

    for (final issue in issues) {
      if (!map.containsKey(issue.itemId)) {
        final item = await (db.select(db.items)..where((i) => i.id.equals(issue.itemId))).getSingle();
        map[issue.itemId] = {
          'itemName': '${item.itemCode} - ${item.itemName}',
          'totalQty': 0.0,
          'totalCost': 0.0,
          'issueCount': 0,
        };
      }
      map[issue.itemId]!['totalQty'] += issue.qty;
      map[issue.itemId]!['totalCost'] += issue.qty * (issue.unitCost ?? 0);
      map[issue.itemId]!['issueCount'] += 1;
    }

    return map.values.toList();
  }
}
