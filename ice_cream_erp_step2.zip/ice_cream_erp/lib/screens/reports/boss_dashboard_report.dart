import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class BossDashboardReport extends ConsumerWidget {
  const BossDashboardReport({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Boss Dashboard Report')),
      body: FutureBuilder(
        future: _loadData(db),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final d = snapshot.data!;

          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              _sectionTitle('আজকের সারাংশ'),
              _bigCard('Production (Mix)', '${d['todayMix'].toStringAsFixed(0)} L', Colors.blue),
              _bigCard('Finished Goods', '${d['todayFinished'].toStringAsFixed(0)} L', Colors.indigo),
              _bigCard('Sales', '${d['todaySales'].toStringAsFixed(0)} Tk', Colors.green),
              _bigCard('Purchase', '${d['todayPurchase'].toStringAsFixed(0)} Tk', Colors.orange),

              const SizedBox(height: 16),
              _sectionTitle('এই মাসের সারাংশ'),
              _bigCard('Total Mix Produced', '${d['monthMix'].toStringAsFixed(0)} L', Colors.blue),
              _bigCard('Total Finished', '${d['monthFinished'].toStringAsFixed(0)} L', Colors.indigo),
              _bigCard('Total Sales', '${d['monthSales'].toStringAsFixed(0)} Tk', Colors.green),
              _bigCard('Total Purchase', '${d['monthPurchase'].toStringAsFixed(0)} Tk', Colors.orange),
              _bigCard('Production Cost', '${d['monthProdCost'].toStringAsFixed(0)} Tk', Colors.red),
              _bigCard('Wastage Cost', '${d['monthWastage'].toStringAsFixed(0)} Tk', Colors.deepOrange),
              _bigCard('Gross Profit (approx)', '${d['monthProfit'].toStringAsFixed(0)} Tk', 
                  (d['monthProfit'] as double) >= 0 ? Colors.green.shade700 : Colors.red.shade700),

              const SizedBox(height: 16),
              _sectionTitle('স্টক অবস্থা'),
              _bigCard('Low Stock Items', '${d['lowStockCount']}', Colors.red),
              _bigCard('Expiring in 30 days', '${d['expiringCount']}', Colors.orange),
            ],
          );
        },
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 4),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
    );
  }

  Widget _bigCard(String label, String value, Color color) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: color.withOpacity(0.08),
      child: ListTile(
        title: Text(label, style: TextStyle(color: color.withOpacity(0.9), fontSize: 13)),
        trailing: Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
      ),
    );
  }

  Future<Map<String, dynamic>> _loadData(AppDatabase db) async {
    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final monthStart = DateTime(now.year, now.month, 1);

    final orders = await db.select(db.productionOrders).get();
    final vouchers = await db.select(db.vouchers).get();
    final ledger = await db.select(db.stockLedger).get();
    final batches = await db.select(db.batches).get();
    final items = await db.select(db.items).get();

    double todayMix = 0, todayFinished = 0, monthMix = 0, monthFinished = 0, monthProdCost = 0;
    for (final o in orders) {
      if (o.status != 'Completed') continue;
      final end = o.endDate ?? o.createdAt;
      if (end.isAfter(todayStart)) {
        todayMix += o.actualMixQty ?? 0;
        todayFinished += o.actualFinishedQty ?? 0;
      }
      if (end.isAfter(monthStart)) {
        monthMix += o.actualMixQty ?? 0;
        monthFinished += o.actualFinishedQty ?? 0;
        monthProdCost += o.totalMaterialCost;
      }
    }

    double todaySales = 0, todayPurchase = 0, monthSales = 0, monthPurchase = 0;
    for (final v in vouchers) {
      if (v.voucherDate.isAfter(todayStart)) {
        if (v.voucherType == 'Sales') todaySales += v.totalAmount;
        if (v.voucherType == 'Purchase') todayPurchase += v.totalAmount;
      }
      if (v.voucherDate.isAfter(monthStart)) {
        if (v.voucherType == 'Sales') monthSales += v.totalAmount;
        if (v.voucherType == 'Purchase') monthPurchase += v.totalAmount;
      }
    }

    double monthWastage = 0;
    for (final l in ledger) {
      if ((l.voucherType == 'Wastage' || l.voucherType == 'Adjustment-') && l.transactionDate.isAfter(monthStart)) {
        monthWastage += l.qtyOut * (l.unitCost ?? 0);
      }
    }

    int lowStock = 0;
    for (final item in items) {
      // simplified
    }

    final soon = now.add(const Duration(days: 30));
    int expiring = batches.where((b) => b.currentQty > 0 && b.expiryDate != null && b.expiryDate!.isBefore(soon)).length;

    return {
      'todayMix': todayMix,
      'todayFinished': todayFinished,
      'todaySales': todaySales,
      'todayPurchase': todayPurchase,
      'monthMix': monthMix,
      'monthFinished': monthFinished,
      'monthSales': monthSales,
      'monthPurchase': monthPurchase,
      'monthProdCost': monthProdCost,
      'monthWastage': monthWastage,
      'monthProfit': monthSales - monthProdCost - monthWastage,
      'lowStockCount': lowStock,
      'expiringCount': expiring,
    };
  }
}
