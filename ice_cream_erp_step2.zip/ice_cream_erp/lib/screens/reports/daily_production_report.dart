import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class DailyProductionReportScreen extends ConsumerWidget {
  const DailyProductionReportScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Daily Production Report')),
      body: StreamBuilder(
        stream: (db.select(db.productionOrders)
              ..where((o) => o.status.equals('Completed'))
              ..orderBy([(o) => OrderingTerm.desc(o.endDate)]))
            .watch(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final orders = snapshot.data!;
          if (orders.isEmpty) {
            return const Center(child: Text('এখনো কোনো Completed Production নেই'));
          }

          double totalMix = 0;
          double totalFinished = 0;
          double totalCost = 0;

          for (final o in orders) {
            totalMix += o.actualMixQty ?? 0;
            totalFinished += o.actualFinishedQty ?? 0;
            totalCost += o.totalMaterialCost;
          }

          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      _sumRow('Total Mix Produced', '${totalMix.toStringAsFixed(1)} L'),
                      _sumRow('Total Finished', '${totalFinished.toStringAsFixed(1)} L'),
                      _sumRow('Total Material Cost', '${totalCost.toStringAsFixed(0)} Tk'),
                      if (totalMix > 0)
                        _sumRow('Avg Overrun', '${((totalFinished - totalMix) / totalMix * 100).toStringAsFixed(1)} %'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text('Production Details', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ...orders.map((o) {
                return Card(
                  child: ListTile(
                    title: Text(o.orderNo),
                    subtitle: Text(
                      'Mix: ${o.actualMixQty?.toStringAsFixed(1) ?? "-"} L  →  '
                      'Finished: ${o.actualFinishedQty?.toStringAsFixed(1) ?? "-"} L\n'
                      'Overrun: ${o.actualOverrun?.toStringAsFixed(1) ?? "-"}%  |  '
                      'Yield: ${o.actualYield?.toStringAsFixed(1) ?? "-"}%  |  '
                      'Cost: ${o.totalMaterialCost.toStringAsFixed(0)} Tk',
                    ),
                    isThreeLine: true,
                  ),
                );
              }),
            ],
          );
        },
      ),
    );
  }

  Widget _sumRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
