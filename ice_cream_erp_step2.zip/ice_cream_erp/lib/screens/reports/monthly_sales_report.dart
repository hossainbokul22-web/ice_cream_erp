import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class MonthlySalesReport extends ConsumerStatefulWidget {
  const MonthlySalesReport({super.key});

  @override
  ConsumerState<MonthlySalesReport> createState() => _MonthlySalesReportState();
}

class _MonthlySalesReportState extends ConsumerState<MonthlySalesReport> {
  late int selectedYear;
  late int selectedMonth;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    selectedYear = now.year;
    selectedMonth = now.month;
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Monthly Sales Report')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: selectedMonth,
                    decoration: const InputDecoration(labelText: 'Month', border: OutlineInputBorder(), isDense: true),
                    items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text(_monthName(i + 1)))),
                    onChanged: (v) => setState(() => selectedMonth = v!),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: selectedYear,
                    decoration: const InputDecoration(labelText: 'Year', border: OutlineInputBorder(), isDense: true),
                    items: [2024, 2025, 2026, 2027].map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
                    onChanged: (v) => setState(() => selectedYear = v!),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder(
              future: _load(db),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final list = snapshot.data!;
                if (list.isEmpty) return const Center(child: Text('এই মাসে কোনো Sales নেই'));

                double total = list.fold(0, (sum, v) => sum + v.totalAmount);

                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    Card(
                      color: Colors.green.shade50,
                      child: ListTile(
                        title: const Text('Total Sales'),
                        trailing: Text('${total.toStringAsFixed(0)} Tk', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...list.map((v) => Card(
                      child: ListTile(
                        title: Text(v.voucherNo),
                        subtitle: Text(v.narration ?? ''),
                        trailing: Text('${v.totalAmount.toStringAsFixed(0)} Tk', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    )),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _monthName(int m) => ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m-1];

  Future<List<Voucher>> _load(AppDatabase db) async {
    final start = DateTime(selectedYear, selectedMonth, 1);
    final end = DateTime(selectedYear, selectedMonth + 1, 1);
    final all = await (db.select(db.vouchers)..where((v) => v.voucherType.equals('Sales'))).get();
    return all.where((v) => v.voucherDate.isAfter(start.subtract(const Duration(seconds: 1))) && v.voucherDate.isBefore(end)).toList();
  }
}
