import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:drift/drift.dart' hide Column;
import '../../providers/database_provider.dart';
import '../../database/app_database.dart';

class MonthlyProductionReport extends ConsumerStatefulWidget {
  const MonthlyProductionReport({super.key});

  @override
  ConsumerState<MonthlyProductionReport> createState() => _MonthlyProductionReportState();
}

class _MonthlyProductionReportState extends ConsumerState<MonthlyProductionReport> {
  late int selectedYear;
  late int selectedMonth;

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    selectedYear = now.year;
    selectedMonth = now.month;
  }

  @override
  Widget build(BuildContext context) {
    final db = ref.watch(databaseProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Monthly Production Report')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: selectedMonth,
                    decoration: const InputDecoration(labelText: 'Month', border: OutlineInputBorder(), isDense: true),
                    items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text(_monthName(i + 1)))),
                    onChanged: (v) => setState(() => selectedMonth = v!),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<int>(
                    value: selectedYear,
                    decoration: const InputDecoration(labelText: 'Year', border: OutlineInputBorder(), isDense: true),
                    items: [2024, 2025, 2026, 2027].map((y) => DropdownMenuItem(value: y, child: Text('$y'))).toList(),
                    onChanged: (v) => setState(() => selectedYear = v!),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: FutureBuilder(
              future: _load(db),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final list = snapshot.data!;
                if (list.isEmpty) return const Center(child: Text('এই মাসে কোনো Completed Production নেই'));

                double totalMix = 0, totalFinished = 0, totalCost = 0;
                for (final o in list) {
                  totalMix += o.actualMixQty ?? 0;
                  totalFinished += o.actualFinishedQty ?? 0;
                  totalCost += o.totalMaterialCost;
                }

                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    Card(
                      color: Colors.blue.shade50,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: [
                            _row('Total Batches', '${list.length}'),
                            _row('Total Mix', '${totalMix.toStringAsFixed(1)} L'),
                            _row('Total Finished', '${totalFinished.toStringAsFixed(1)} L'),
                            _row('Avg Overrun', totalMix > 0 ? '${((totalFinished - totalMix) / totalMix * 100).toStringAsFixed(1)} %' : '-'),
                            _row('Total Material Cost', '${totalCost.toStringAsFixed(0)} Tk'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ...list.map((o) => Card(
                      child: ListTile(
                        title: Text(o.orderNo),
                        subtitle: Text(
                          'Mix: ${o.actualMixQty?.toStringAsFixed(1)} L → Finished: ${o.actualFinishedQty?.toStringAsFixed(1)} L\n'
                          'Overrun: ${o.actualOverrun?.toStringAsFixed(1)}% | Cost: ${o.totalMaterialCost.toStringAsFixed(0)} Tk',
                        ),
                        isThreeLine: true,
                      ),
                    )),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _row(String l, String v) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 2),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(l), Text(v, style: const TextStyle(fontWeight: FontWeight.bold))]),
  );

  String _monthName(int m) => ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][m-1];

  Future<List<ProductionOrder>> _load(AppDatabase db) async {
    final start = DateTime(selectedYear, selectedMonth, 1);
    final end = DateTime(selectedYear, selectedMonth + 1, 1);
    final all = await (db.select(db.productionOrders)..where((o) => o.status.equals('Completed'))).get();
    return all.where((o) {
      final d = o.endDate ?? o.createdAt;
      return d.isAfter(start.subtract(const Duration(seconds: 1))) && d.isBefore(end);
    }).toList();
  }
}
