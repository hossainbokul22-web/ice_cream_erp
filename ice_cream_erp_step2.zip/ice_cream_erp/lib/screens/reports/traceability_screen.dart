import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/database_provider.dart';
import '../../services/production_service.dart';

class TraceabilityScreen extends ConsumerStatefulWidget {
  const TraceabilityScreen({super.key});

  @override
  ConsumerState<TraceabilityScreen> createState() => _TraceabilityScreenState();
}

class _TraceabilityScreenState extends ConsumerState<TraceabilityScreen> {
  final batchCtrl = TextEditingController();
  String mode = 'Backward'; // Backward = FG → Raw, Forward = Raw → FG
  List<Map<String, dynamic>>? results;
  bool loading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Batch Traceability')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'Backward', label: Text('FG → Raw (Backward)')),
              ButtonSegment(value: 'Forward', label: Text('Raw → FG (Forward)')),
            ],
            selected: {mode},
            onSelectionChanged: (s) => setState(() {
              mode = s.first;
              results = null;
            }),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: batchCtrl,
            decoration: InputDecoration(
              labelText: mode == 'Backward' ? 'Finished Goods Batch No' : 'Raw Material Batch No',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: _search,
              ),
            ),
            onSubmitted: (_) => _search(),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: loading ? null : _search,
            icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
            label: Text(loading ? 'খুঁজছি...' : 'Trace করুন'),
          ),
          const SizedBox(height: 20),
          if (results != null) ...[
            Text(
              mode == 'Backward' ? 'এই Finished Batch-এ ব্যবহৃত Raw Materials:' : 'এই Raw Batch যেসব Finished Batch-এ গেছে:',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (results!.isEmpty)
              const Card(child: ListTile(title: Text('কোনো তথ্য পাওয়া যায়নি')))
            else
              ...results!.map((r) {
                if (mode == 'Backward') {
                  return Card(
                    child: ListTile(
                      title: Text('${r['itemCode']} - ${r['itemName']}'),
                      subtitle: Text('Batch: ${r['batchNo']}  |  Qty: ${(r['qty'] as double).toStringAsFixed(2)}'),
                      trailing: Text('${(r['unitCost'] as double? ?? 0).toStringAsFixed(1)}', style: const TextStyle(fontSize: 12)),
                    ),
                  );
                } else {
                  return Card(
                    child: ListTile(
                      title: Text('FG Batch: ${r['finishedBatchNo']}'),
                      subtitle: Text('${r['finishedItem']}\nUsed Qty: ${(r['qtyUsed'] as double).toStringAsFixed(2)}  |  FG Qty: ${(r['finishedQty'] as double).toStringAsFixed(1)}'),
                      isThreeLine: true,
                    ),
                  );
                }
              }),
          ],
        ],
      ),
    );
  }

  Future<void> _search() async {
    if (batchCtrl.text.trim().isEmpty) return;
    setState(() => loading = true);
    final service = ref.read(productionServiceProvider);
    List<Map<String, dynamic>> data;
    if (mode == 'Backward') {
      data = await service.getBackwardTrace(batchCtrl.text.trim());
    } else {
      data = await service.getForwardTrace(batchCtrl.text.trim());
    }
    setState(() {
      results = data;
      loading = false;
    });
  }
}
