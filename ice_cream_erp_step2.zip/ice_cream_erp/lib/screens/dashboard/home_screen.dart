import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../inventory/receive_stock_screen.dart';
import '../inventory/stock_adjustment_screen.dart';
import '../accounts/sales_screen.dart';
import '../reports/daily_production_report.dart';
import '../reports/material_consumption_report.dart';
import '../reports/expiry_alert_screen.dart';
import '../reports/boss_dashboard_report.dart';
import '../reports/monthly_production_report.dart';
import '../reports/monthly_sales_report.dart';
import '../reports/traceability_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ice Cream ERP')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          // Quick Actions
          const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _quick(context, 'Opening', Icons.account_balance_wallet, Colors.deepOrange, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: true)));
              })),
              const SizedBox(width: 6),
              Expanded(child: _quick(context, 'Purchase', Icons.add_shopping_cart, Colors.teal, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiveStockScreen(isOpening: false)));
              })),
              const SizedBox(width: 6),
              Expanded(child: _quick(context, 'Sales', Icons.point_of_sale, Colors.green, () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const SalesScreen()));
              })),
            ],
          ),
          const SizedBox(height: 16),

          // Boss Report
          const Text('Boss Report', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.dashboard, 'Boss Dashboard', 'আজ + এই মাসের সারাংশ', Colors.purple, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const BossDashboardReport()));
          }),

          const SizedBox(height: 12),
          const Text('Daily Reports', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.assessment, 'Daily Production', 'Mix, Finished, Overrun, Cost', Colors.blue, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const DailyProductionReportScreen()));
          }),
          _tile(context, Icons.list_alt, 'Material Consumption', 'কাঁচামাল খরচ', Colors.orange, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MaterialConsumptionReportScreen()));
          }),
          _tile(context, Icons.warning_amber, 'Expiry Alert', '৩০ দিনের মধ্যে', Colors.deepOrange, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const ExpiryAlertScreen()));
          }),
          _tile(context, Icons.timeline, 'Batch Traceability', 'Forward + Backward Trace', Colors.purple, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const TraceabilityScreen()));
          }),

          const SizedBox(height: 12),
          const Text('Monthly Reports', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.calendar_month, 'Monthly Production', 'মাস সিলেক্ট করে দেখুন', Colors.indigo, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MonthlyProductionReport()));
          }),
          _tile(context, Icons.shopping_bag, 'Monthly Sales', 'মাসিক বিক্রয় রিপোর্ট', Colors.green, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const MonthlySalesReport()));
          }),
          _tile(context, Icons.account_balance, 'Profit & Loss', 'পূর্ণ P&L', Colors.teal, () {
            context.push('/profit-loss');
          }),

          const SizedBox(height: 12),
          const Text('Modules', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _tile(context, Icons.precision_manufacturing, 'Production', 'Batch, Overrun, Cost/L', Colors.deepPurple, () => context.push('/production')),
          _tile(context, Icons.inventory_2, 'Stock Summary', 'Closing Balance', Colors.teal, () => context.push('/stock')),
          _tile(context, Icons.tune, 'Adjustment / Wastage', 'নষ্ট / Adjustment', Colors.red, () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => const StockAdjustmentScreen()));
          }),
          _tile(context, Icons.science, 'Recipes / BOM', 'Auto Calculation', Colors.indigo, () => context.push('/recipes')),
          _tile(context, Icons.water_drop, 'Tanks', 'Mixing & Aging', Colors.cyan, () => context.push('/tanks')),
          _tile(context, Icons.category, 'Item Master', 'Raw / Packaging / FG', Colors.brown, () => context.push('/items')),
          _tile(context, Icons.receipt_long, 'Vouchers', 'All entries', Colors.blueGrey, () => context.push('/vouchers')),
        ],
      ),
    );
  }

  Widget _quick(BuildContext context, String title, IconData icon, Color color, VoidCallback onTap) {
    return Card(
      color: color.withOpacity(0.1),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 4),
              Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String sub, Color color, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 7),
      child: ListTile(
        dense: true,
        leading: CircleAvatar(radius: 18, backgroundColor: color.withOpacity(0.15), child: Icon(icon, color: color, size: 20)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 11)),
        trailing: const Icon(Icons.chevron_right, size: 18),
        onTap: onTap,
      ),
    );
  }
}
