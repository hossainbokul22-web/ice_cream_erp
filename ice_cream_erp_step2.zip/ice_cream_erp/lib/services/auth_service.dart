import 'package:flutter/foundation.dart';

enum UserRole { boss, operator }

class AppUser {
  final String name;
  final UserRole role;
  AppUser(this.name, this.role);
}

class AuthService extends ChangeNotifier {
  AppUser? _currentUser;
  AppUser? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;
  bool get isBoss => _currentUser?.role == UserRole.boss;

  // Simple hardcoded users (can be moved to DB later)
  final Map<String, Map<String, dynamic>> _users = {
    'boss': {'password': 'boss123', 'name': 'Boss', 'role': UserRole.boss},
    'operator': {'password': 'op123', 'name': 'Operator', 'role': UserRole.operator},
  };

  bool login(String username, String password) {
    final u = _users[username.toLowerCase()];
    if (u != null && u['password'] == password) {
      _currentUser = AppUser(u['name'], u['role']);
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}

final authService = AuthService();
