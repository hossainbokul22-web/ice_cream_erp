import 'package:drift/drift.dart';
import '../database/app_database.dart';

class StockService {
  final AppDatabase db;

  StockService(this.db);

  /// Opening Balance বা Purchase Receive — Batch + Expiry সহ স্টক বাড়ায়
  Future<void> receiveStock({
    required int itemId,
    required double qty,
    required double unitCost,
    required String batchNo,
    DateTime? mfgDate,
    DateTime? expiryDate,
    int? warehouseId,
    String voucherType = 'Purchase',
    String? narration,
  }) async {
    await db.transaction(() async {
      final existing = await (db.select(db.batches)
            ..where((b) => b.batchNo.equals(batchNo) & b.itemId.equals(itemId)))
          .getSingleOrNull();

      int batchId;
      if (existing != null) {
        batchId = existing.id;
        await (db.update(db.batches)..where((b) => b.id.equals(batchId))).write(
          BatchesCompanion(
            currentQty: Value(existing.currentQty + qty),
            initialQty: Value(existing.initialQty + qty),
            unitCost: Value(unitCost),
          ),
        );
      } else {
        batchId = await db.into(db.batches).insert(BatchesCompanion.insert(
              batchNo: batchNo,
              itemId: itemId,
              warehouseId: Value(warehouseId),
              mfgDate: Value(mfgDate),
              expiryDate: Value(expiryDate),
              initialQty: qty,
              currentQty: qty,
              unitCost: Value(unitCost),
            ));
      }

      await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
            voucherType: voucherType,
            itemId: itemId,
            batchId: Value(batchId),
            warehouseId: Value(warehouseId),
            qtyIn: Value(qty),
            unitCost: Value(unitCost),
            transactionDate: DateTime.now(),
            narration: Value(narration ?? (voucherType == 'Opening' ? 'Opening Balance' : 'Purchase Receive')),
          ));
    });
  }

  Future<double> getItemStock(int itemId, {int? warehouseId}) async {
    final query = db.selectOnly(db.stockLedger)
      ..addColumns([db.stockLedger.qtyIn.sum(), db.stockLedger.qtyOut.sum()])
      ..where(db.stockLedger.itemId.equals(itemId));

    if (warehouseId != null) {
      query.where(db.stockLedger.warehouseId.equals(warehouseId));
    }

    final row = await query.getSingle();
    final qtyIn = row.read(db.stockLedger.qtyIn.sum()) ?? 0.0;
    final qtyOut = row.read(db.stockLedger.qtyOut.sum()) ?? 0.0;
    return qtyIn - qtyOut;
  }

  Future<List<Batch>> getAvailableBatches(int itemId) {
    return (db.select(db.batches)
          ..where((b) => b.itemId.equals(itemId) & b.currentQty.isBiggerThanValue(0))
          ..orderBy([(b) => OrderingTerm(expression: b.expiryDate, mode: OrderingMode.asc)]))
        .get();
  }

  Future<List<Map<String, dynamic>>> getStockSummary({int? warehouseId}) async {
    final items = await (db.select(db.items)..where((i) => i.isActive.equals(true))).get();
    List<Map<String, dynamic>> summary = [];

    for (final item in items) {
      final stock = await getItemStock(item.id, warehouseId: warehouseId);
      final batches = await getAvailableBatches(item.id);
      double stockValue = 0;
      for (final b in batches) {
        stockValue += b.currentQty * b.unitCost;
      }

      summary.add({
        'item': item,
        'currentStock': stock,
        'stockValue': stockValue,
        'batches': batches,
        'isLowStock': stock < item.minStock,
      });
    }
    return summary;
  }

  Future<List<StockLedgerData>> getItemLedger(int itemId) {
    return (db.select(db.stockLedger)
          ..where((l) => l.itemId.equals(itemId))
          ..orderBy([(l) => OrderingTerm.desc(l.transactionDate)]))
        .get();
  }
}
