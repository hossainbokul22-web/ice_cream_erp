import 'package:drift/drift.dart';
import '../database/app_database.dart';

class ProductionService {
  final AppDatabase db;

  ProductionService(this.db);

  Future<int> createProductionOrder({
    required String orderNo,
    required int recipeId,
    required double targetMixQty,
    required String targetUnit,
    int? mixingTankId,
    int? agingTankId,
    String? notes,
  }) async {
    final recipe = await (db.select(db.recipes)..where((r) => r.id.equals(recipeId))).getSingle();
    return db.into(db.productionOrders).insert(ProductionOrdersCompanion.insert(
      orderNo: orderNo,
      recipeId: recipeId,
      targetQty: targetMixQty,
      targetUnit: targetUnit,
      plannedOverrun: Value(recipe.targetOverrun),
      mixingTankId: Value(mixingTankId),
      agingTankId: Value(agingTankId),
      notes: Value(notes),
      status: const Value('Planned'),
    ));
  }

  Future<List<Map<String, dynamic>>> getRequiredMaterials(int productionOrderId) async {
    final order = await (db.select(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).getSingle();
    final recipe = await (db.select(db.recipes)..where((r) => r.id.equals(order.recipeId))).getSingle();
    final lines = await (db.select(db.recipeLines)..where((l) => l.recipeId.equals(recipe.id))).get();
    final scaleFactor = order.targetQty / recipe.baseQty;

    List<Map<String, dynamic>> materials = [];
    for (final line in lines) {
      final item = await (db.select(db.items)..where((i) => i.id.equals(line.itemId))).getSingle();
      final requiredQty = line.qty * scaleFactor * (1 + (line.wastagePercent / 100));
      materials.add({
        'itemId': item.id,
        'itemCode': item.itemCode,
        'itemName': item.itemName,
        'requiredQty': requiredQty,
        'unit': line.unit,
        'wastagePercent': line.wastagePercent,
        'standardCost': item.standardCost,
      });
    }
    return materials;
  }

  Future<void> issueMaterials({
    required int productionOrderId,
    required List<Map<String, dynamic>> issues,
  }) async {
    await db.transaction(() async {
      double totalCost = 0;
      for (final issue in issues) {
        final itemId = issue['itemId'] as int;
        final batchId = issue['batchId'] as int?;
        final qty = issue['qty'] as double;
        final unitCost = (issue['unitCost'] as num?)?.toDouble() ?? 0.0;

        await db.into(db.productionIssues).insert(ProductionIssuesCompanion.insert(
          productionOrderId: productionOrderId,
          itemId: itemId,
          batchId: Value(batchId),
          qty: qty,
          unitCost: Value(unitCost),
        ));

        await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
          voucherType: 'ProductionIssue',
          itemId: itemId,
          batchId: Value(batchId),
          qtyOut: Value(qty),
          unitCost: Value(unitCost),
          transactionDate: DateTime.now(),
          narration: Value('Issued to PO'),
        ));

        if (batchId != null) {
          final batch = await (db.select(db.batches)..where((b) => b.id.equals(batchId))).getSingle();
          await (db.update(db.batches)..where((b) => b.id.equals(batchId)))
              .write(BatchesCompanion(currentQty: Value(batch.currentQty - qty)));
        }
        totalCost += qty * unitCost;
      }
      await (db.update(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).write(
        ProductionOrdersCompanion(totalMaterialCost: Value(totalCost), status: const Value('Mixing'), startDate: Value(DateTime.now())),
      );
    });
  }

  Future<void> completeMixing({required int productionOrderId, required double actualMixQty, required int mixingTankId}) async {
    await (db.update(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).write(
      ProductionOrdersCompanion(actualMixQty: Value(actualMixQty), mixingTankId: Value(mixingTankId), status: const Value('Aging')),
    );
  }

  Future<void> moveToAging({required int productionOrderId, required int agingTankId}) async {
    final order = await (db.select(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).getSingle();
    await db.transaction(() async {
      if (order.mixingTankId != null) {
        await (db.update(db.tanks)..where((t) => t.id.equals(order.mixingTankId!))).write(
          const TanksCompanion(currentQty: Value(0), status: Value('Empty'), currentItemId: Value(null)),
        );
      }
      await (db.update(db.tanks)..where((t) => t.id.equals(agingTankId))).write(
        TanksCompanion(currentQty: Value(order.actualMixQty ?? 0), status: const Value('InUse')),
      );
      await (db.update(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).write(
        ProductionOrdersCompanion(agingTankId: Value(agingTankId), status: const Value('Aging')),
      );
    });
  }

  /// Complete with Overrun + optional Packaging auto consumption
  Future<void> completeProduction({
    required int productionOrderId,
    required double actualFinishedQty,
    required String finishedBatchNo,
    required int finishedItemId,
    required int warehouseId,
    DateTime? mfgDate,
    DateTime? expiryDate,
    List<Map<String, dynamic>>? packagingIssues, // [{itemId, batchId, qty, unitCost}]
  }) async {
    final order = await (db.select(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).getSingle();
    if (order.actualMixQty == null || order.actualMixQty! <= 0) throw Exception('Actual Mix Qty not recorded');

    final actualOverrun = ((actualFinishedQty - order.actualMixQty!) / order.actualMixQty!) * 100;
    final actualYield = (order.actualMixQty! / order.targetQty) * 100;
    final costPerLiterMix = order.totalMaterialCost / order.actualMixQty!;
    final costPerLiterFinished = costPerLiterMix / (1 + (actualOverrun / 100));

    await db.transaction(() async {
      // Finished Goods Batch
      final batchId = await db.into(db.batches).insert(BatchesCompanion.insert(
        batchNo: finishedBatchNo,
        itemId: finishedItemId,
        warehouseId: Value(warehouseId),
        mfgDate: Value(mfgDate ?? DateTime.now()),
        expiryDate: Value(expiryDate),
        initialQty: actualFinishedQty,
        currentQty: actualFinishedQty,
        unitCost: Value(costPerLiterFinished),
      ));

      await db.into(db.productionReceipts).insert(ProductionReceiptsCompanion.insert(
        productionOrderId: productionOrderId,
        itemId: finishedItemId,
        batchNo: finishedBatchNo,
        qty: actualFinishedQty,
        unit: const Value('L'),
        overrunPercent: Value(actualOverrun),
        unitCost: Value(costPerLiterFinished),
        mfgDate: Value(mfgDate ?? DateTime.now()),
        expiryDate: Value(expiryDate),
        warehouseId: Value(warehouseId),
      ));

      await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
        voucherType: 'ProductionReceipt',
        itemId: finishedItemId,
        batchId: Value(batchId),
        warehouseId: Value(warehouseId),
        qtyIn: Value(actualFinishedQty),
        unitCost: Value(costPerLiterFinished),
        transactionDate: DateTime.now(),
        narration: Value('FG Receipt. Overrun ${actualOverrun.toStringAsFixed(1)}%'),
      ));

      // Packaging auto consumption
      if (packagingIssues != null) {
        for (final p in packagingIssues) {
          final pItemId = p['itemId'] as int;
          final pBatchId = p['batchId'] as int?;
          final pQty = p['qty'] as double;
          final pCost = (p['unitCost'] as num?)?.toDouble() ?? 0.0;

          await db.into(db.productionIssues).insert(ProductionIssuesCompanion.insert(
            productionOrderId: productionOrderId,
            itemId: pItemId,
            batchId: Value(pBatchId),
            qty: pQty,
            unitCost: Value(pCost),
          ));
          await db.into(db.stockLedger).insert(StockLedgerCompanion.insert(
            voucherType: 'PackagingIssue',
            itemId: pItemId,
            batchId: Value(pBatchId),
            qtyOut: Value(pQty),
            unitCost: Value(pCost),
            transactionDate: DateTime.now(),
            narration: Value('Auto Packaging for $finishedBatchNo'),
          ));
          if (pBatchId != null) {
            final b = await (db.select(db.batches)..where((x) => x.id.equals(pBatchId))).getSingle();
            await (db.update(db.batches)..where((x) => x.id.equals(pBatchId)))
                .write(BatchesCompanion(currentQty: Value(b.currentQty - pQty)));
          }
        }
      }

      if (order.agingTankId != null) {
        await (db.update(db.tanks)..where((t) => t.id.equals(order.agingTankId!))).write(
          const TanksCompanion(currentQty: Value(0), status: Value('Empty'), currentItemId: Value(null)),
        );
      }

      await (db.update(db.productionOrders)..where((o) => o.id.equals(productionOrderId))).write(
        ProductionOrdersCompanion(
          actualFinishedQty: Value(actualFinishedQty),
          actualOverrun: Value(actualOverrun),
          actualYield: Value(actualYield),
          status: const Value('Completed'),
          endDate: Value(DateTime.now()),
        ),
      );
    });
  }

  Future<Map<String, dynamic>> getOrderDetails(int orderId) async {
    final order = await (db.select(db.productionOrders)..where((o) => o.id.equals(orderId))).getSingle();
    final recipe = await (db.select(db.recipes)..where((r) => r.id.equals(order.recipeId))).getSingle();
    final issues = await (db.select(db.productionIssues)..where((i) => i.productionOrderId.equals(orderId))).get();

    // Standard vs Actual
    final materials = await getRequiredMaterials(orderId);
    double standardCost = 0;
    for (final m in materials) {
      standardCost += (m['requiredQty'] as double) * (m['standardCost'] as double);
    }
    final actualCost = order.totalMaterialCost;
    final variance = actualCost - standardCost;
    final variancePercent = standardCost > 0 ? (variance / standardCost) * 100 : 0;

    return {
      'order': order,
      'recipe': recipe,
      'issues': issues,
      'standardCost': standardCost,
      'actualCost': actualCost,
      'variance': variance,
      'variancePercent': variancePercent,
      'costPerLiterMix': order.actualMixQty != null && order.actualMixQty! > 0 ? order.totalMaterialCost / order.actualMixQty! : null,
      'costPerLiterFinished': order.actualOverrun != null && order.actualMixQty != null
          ? (order.totalMaterialCost / order.actualMixQty!) / (1 + (order.actualOverrun! / 100))
          : null,
    };
  }

  /// Backward Traceability: Finished Batch → কোন Raw Batches ব্যবহার হয়েছে
  Future<List<Map<String, dynamic>>> getBackwardTrace(String finishedBatchNo) async {
    final receipt = await (db.select(db.productionReceipts)..where((r) => r.batchNo.equals(finishedBatchNo))).getSingleOrNull();
    if (receipt == null) return [];
    final issues = await (db.select(db.productionIssues)..where((i) => i.productionOrderId.equals(receipt.productionOrderId))).get();
    List<Map<String, dynamic>> result = [];
    for (final issue in issues) {
      final item = await (db.select(db.items)..where((i) => i.id.equals(issue.itemId))).getSingle();
      String? batchNo;
      if (issue.batchId != null) {
        final b = await (db.select(db.batches)..where((x) => x.id.equals(issue.batchId!))).getSingleOrNull();
        batchNo = b?.batchNo;
      }
      result.add({
        'itemCode': item.itemCode,
        'itemName': item.itemName,
        'qty': issue.qty,
        'batchNo': batchNo ?? '-',
        'unitCost': issue.unitCost,
      });
    }
    return result;
  }

  /// Forward Traceability: Raw Batch → কোন কোন Finished Batch-এ গেছে
  Future<List<Map<String, dynamic>>> getForwardTrace(String rawBatchNo) async {
    final batch = await (db.select(db.batches)..where((b) => b.batchNo.equals(rawBatchNo))).getSingleOrNull();
    if (batch == null) return [];
    final issues = await (db.select(db.productionIssues)..where((i) => i.batchId.equals(batch.id))).get();
    List<Map<String, dynamic>> result = [];
    for (final issue in issues) {
      final receipt = await (db.select(db.productionReceipts)..where((r) => r.productionOrderId.equals(issue.productionOrderId))).getSingleOrNull();
      if (receipt != null) {
        final item = await (db.select(db.items)..where((i) => i.id.equals(receipt.itemId))).getSingle();
        result.add({
          'finishedBatchNo': receipt.batchNo,
          'finishedItem': item.itemName,
          'qtyUsed': issue.qty,
          'finishedQty': receipt.qty,
        });
      }
    }
    return result;
  }
}
